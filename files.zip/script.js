/* =============================================================
   BLOODLINK — DEMO PROTOTYPE LOGIC
   Pure vanilla JS. All data below is simulated demo data for a
   hackathon prototype — nothing here connects to a real backend.
============================================================== */

/* ---------------------------------------------------------------
   1. DEMO DATA
---------------------------------------------------------------- */
const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

// Simulated real-time inventory (this hospital / local network)
const bloodInventory = {
  "A+":  { units: 22, note: "Stable stock" },
  "A-":  { units: 4,  note: "Restock recommended" },
  "B+":  { units: 2,  note: "Immediate restock needed" },
  "B-":  { units: 9,  note: "Monitor closely" },
  "AB+": { units: 14, note: "Stable stock" },
  "AB-": { units: 3,  note: "Immediate restock needed" },
  "O+":  { units: 24, note: "3 units expiring soon" },
  "O-":  { units: 6,  note: "Universal donor — monitor" },
};

// Units approaching expiry (simulated)
const expiringUnits = [
  { code: "O245", group: "O+", daysLeft: 2 },
  { code: "A182", group: "A+", daysLeft: 4 },
  { code: "B097", group: "B-", daysLeft: 5 },
];

// Demo blood banks used by the matching engine
const bloodBankPool = [
  { name: "CityCare Blood Bank", baseDistance: 2.4, baseUnits: 8, baseScore: 96 },
  { name: "LifeLine Blood Bank", baseDistance: 4.1, baseUnits: 5, baseScore: 89 },
  { name: "MedPlus Blood Bank",  baseDistance: 6.8, baseUnits: 6, baseScore: 84 },
];

// Demo verified donors (fictional names only)
const donors = [
  { name: "Rahul",  group: "O+",  distance: 1.8, status: "eligible" },
  { name: "Ayesha", group: "O+",  distance: 4.2, status: "eligible" },
  { name: "Karan",  group: "A+",  distance: 3.1, status: "eligible" },
  { name: "Sneha",  group: "A-",  distance: 5.5, status: "eligible" },
  { name: "Vikram", group: "B+",  distance: 2.9, status: "cooldown" },
  { name: "Meera",  group: "B-",  distance: 6.0, status: "eligible" },
  { name: "Arjun",  group: "AB+", distance: 3.7, status: "eligible" },
  { name: "Priya",  group: "AB-", distance: 7.2, status: "eligible" },
  { name: "Farhan", group: "O-",  distance: 4.8, status: "eligible" },
  { name: "Neha",   group: "O+",  distance: 2.0, status: "cooldown" },
];

// Base notification feed (most recent first)
let notifications = [
  { icon: "⚠️", title: "A+ inventory is low", time: "10 min ago" },
  { icon: "⏳", title: "3 units approaching expiry", time: "25 min ago" },
  { icon: "🩸", title: "O+ units available nearby", time: "40 min ago" },
  { icon: "✅", title: "CityCare Blood Bank confirmed request #BL-1019", time: "1 hr ago" },
  { icon: "🚨", title: "Critical blood request received", time: "2 hr ago" },
];

/* ---------------------------------------------------------------
   2. APP STATE
---------------------------------------------------------------- */
const state = {
  role: null,
  orgName: "",
  contact: "",
  requestCounter: 1023,      // first created request becomes #BL-1024
  currentRequest: null,      // the in-flight emergency request object
  requestHistory: [],        // resolved requests
  baselineActiveRequests: 1, // one "already in progress" request, for demo realism
};

// Timeline milestone thresholds — see renderTimeline() for how these are used
const NOTIFY_STEPS = [
  { label: "Request Created", threshold: 0 },
  { label: "Matching Completed", threshold: 1 },
  { label: "Resource Found", threshold: 2 },
  { label: "Notification Sent", threshold: 3 },
  { label: "Blood Collection", threshold: 5 },
  { label: "Request Resolved", threshold: 6 },
];
const RESOLVE_STEPS = [
  { label: "Request Created", threshold: 0 },
  { label: "Resource Matched", threshold: 2 },
  { label: "Resource Notified", threshold: 3 },
  { label: "Resource Confirmed", threshold: 4 },
  { label: "Blood Received", threshold: 5 },
  { label: "Request Resolved", threshold: 6 },
];

/* ---------------------------------------------------------------
   3. HELPERS
---------------------------------------------------------------- */
function $(selector) { return document.querySelector(selector); }
function $all(selector) { return Array.from(document.querySelectorAll(selector)); }

function statusForUnits(units) {
  if (units <= 3) return "critical";
  if (units <= 10) return "low";
  return "available";
}

function statusColorVar(status) {
  if (status === "critical") return "var(--red)";
  if (status === "low") return "var(--amber)";
  return "var(--green)";
}

function statusLabel(status) {
  if (status === "critical") return "Critical";
  if (status === "low") return "Low";
  return "Available";
}

function showToast(message, type = "default") {
  const container = $("#toast-container");
  const toast = document.createElement("div");
  toast.className = "toast" + (type === "success" ? " toast-success" : type === "warning" ? " toast-error" : "");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("toast-out");
    setTimeout(() => toast.remove(), 220);
  }, 3200);
}

function pushNotification(icon, title) {
  notifications.unshift({ icon, title, time: "just now" });
  $("#bell-dot").classList.remove("hidden");
}

/* ---------------------------------------------------------------
   4. LANDING — ROLE SELECT + LOGIN
---------------------------------------------------------------- */
function initLanding() {
  $all(".role-card").forEach((card) => {
    card.addEventListener("click", () => {
      $all(".role-card").forEach((c) => c.classList.remove("selected"));
      card.classList.add("selected");
      state.role = card.dataset.role;
      $("#login-role-label").textContent = card.dataset.label;
      $("#login-panel").classList.remove("hidden");
      $("#login-panel").scrollIntoView({ behavior: "smooth", block: "center" });
    });
  });

  $("#btn-change-role").addEventListener("click", () => {
    $("#login-panel").classList.add("hidden");
    $all(".role-card").forEach((c) => c.classList.remove("selected"));
    state.role = null;
  });

  $("#login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    state.orgName = $("#input-org").value.trim() || "Demo User";
    state.contact = $("#input-contact").value.trim();
    enterApp();
  });
}

/* ---------------------------------------------------------------
   5. ENTER APP / ROLE-BASED SHELL SETUP
---------------------------------------------------------------- */
const ROLE_LABELS = {
  hospital: "Hospital",
  bloodbank: "Blood Bank",
  donor: "Donor",
  admin: "Admin",
};

const PAGE_TITLES = {
  dashboard: {
    hospital: "Hospital Dashboard",
    bloodbank: "Blood Bank Dashboard",
    donor: "Donor Dashboard",
    admin: "System Overview",
  },
  emergency: "Emergency Blood Request",
  inventory: "Blood Inventory",
  matching: "Smart Matching",
  notify: "Notify & Coordinate",
  resolve: "Blood Request Resolution",
  donors: "Donor Network",
  notifications: "Notifications",
  history: "Request History",
};

function enterApp() {
  $("#screen-landing").classList.add("hidden");
  $("#app-shell").classList.remove("hidden");

  // Profile chip
  $("#profile-name").textContent = state.orgName;
  $("#profile-role").textContent = ROLE_LABELS[state.role];
  $("#profile-avatar").textContent = state.orgName.charAt(0).toUpperCase();

  // Sidebar nav visibility by role
  $all(".nav-item[data-roles]").forEach((item) => {
    const roles = item.dataset.roles.split(",");
    item.classList.toggle("hidden", !roles.includes(state.role));
  });

  // Show correct dashboard variant
  $all(".dash-variant").forEach((el) => el.classList.add("hidden"));
  $("#dash-" + state.role).classList.remove("hidden");

  if (state.role === "hospital") {
    $("#hosp-name-inline").textContent = ", " + state.orgName;
  }
  if (state.role === "donor") {
    $("#donor-name-inline").textContent = state.orgName;
    $("#donor-profile-name").textContent = state.orgName;
  }

  renderAll();
  navigateTo("dashboard");
}

function initLogout() {
  $("#btn-logout").addEventListener("click", () => {
    $("#app-shell").classList.add("hidden");
    $("#screen-landing").classList.remove("hidden");
    $("#login-panel").classList.add("hidden");
    $all(".role-card").forEach((c) => c.classList.remove("selected"));
    $("#login-form").reset();
    state.role = null;
    showToast("Logged out of demo session.");
  });
}

/* ---------------------------------------------------------------
   6. NAVIGATION
---------------------------------------------------------------- */
function navigateTo(page) {
  $all(".page").forEach((p) => p.classList.remove("active"));
  $("#page-" + page).classList.add("active");

  $all(".nav-item[data-page]").forEach((item) => {
    item.classList.toggle("active", item.dataset.page === page);
  });

  const title = PAGE_TITLES[page];
  $("#topbar-title").textContent = typeof title === "object" ? title[state.role] : title;

  // Refresh page-specific content each time it's opened
  if (page === "dashboard") renderAll();
  if (page === "inventory") renderInventoryPage();
  if (page === "donors") renderDonorsPage();
  if (page === "notifications") renderNotificationsPage();
  if (page === "history") renderHistoryPage();

  // Close mobile sidebar after navigating
  $("#sidebar").classList.remove("open");
}

function initNav() {
  $all(".nav-item[data-page]").forEach((item) => {
    item.addEventListener("click", () => navigateTo(item.dataset.page));
  });
  $all("[data-nav]").forEach((btn) => {
    btn.addEventListener("click", () => navigateTo(btn.dataset.nav));
  });
  $("#btn-mobile-nav").addEventListener("click", () => {
    $("#sidebar").classList.toggle("open");
  });
  $("#btn-bell").addEventListener("click", () => {
    $("#bell-dot").classList.add("hidden");
    navigateTo("notifications");
  });
}

/* ---------------------------------------------------------------
   7. INVENTORY RENDERING
---------------------------------------------------------------- */
function bloodCardHTML(group) {
  const data = bloodInventory[group];
  const status = statusForUnits(data.units);
  return `
    <div class="blood-card" style="--status-color:${statusColorVar(status)}">
      <div class="blood-card-top">
        <span class="blood-group-label">${group}</span>
        <span class="status-badge status-${status}">${statusLabel(status)}</span>
      </div>
      <span class="blood-units">${data.units} units available</span>
      <span class="blood-card-note">${data.note}</span>
    </div>`;
}

function renderInventoryGrid(containerId) {
  const el = $(containerId);
  if (!el) return;
  el.innerHTML = BLOOD_GROUPS.map(bloodCardHTML).join("");
}

function renderInventoryPage() {
  renderInventoryGrid("#inventory-grid-full");
  const list = $("#expiry-list");
  list.innerHTML = expiringUnits
    .map(
      (u) => `
      <div class="expiry-row">
        <span>${u.group} Unit <strong>#${u.code}</strong></span>
        <strong>expires in ${u.daysLeft} day${u.daysLeft === 1 ? "" : "s"}</strong>
      </div>`
    )
    .join("");
  $("#expiry-warning-pill").textContent = `${expiringUnits.length} Expiring Soon`;
}

/* ---------------------------------------------------------------
   8. DASHBOARD RENDERING (role-aware)
---------------------------------------------------------------- */
function activeRequestCount() {
  return state.baselineActiveRequests + (state.currentRequest && !state.currentRequest.resolved ? 1 : 0);
}

function criticalGroupCount() {
  return BLOOD_GROUPS.filter((g) => statusForUnits(bloodInventory[g].units) === "critical").length;
}

function totalUnits() {
  return BLOOD_GROUPS.reduce((sum, g) => sum + bloodInventory[g].units, 0);
}

function renderAll() {
  if (state.role === "hospital") renderHospitalDashboard();
  if (state.role === "bloodbank") renderBloodBankDashboard();
  if (state.role === "donor") renderDonorDashboard();
  if (state.role === "admin") renderAdminDashboard();
}

function renderHospitalDashboard() {
  $("#stat-available-units").textContent = totalUnits();
  $("#stat-critical-groups").textContent = criticalGroupCount();
  $("#stat-active-requests").textContent = activeRequestCount();
  $("#stat-nearby-resources").textContent = bloodBankPool.length + donors.length;
  renderInventoryGrid("#inventory-grid-dashboard");
}

function renderBloodBankDashboard() {
  $("#bb-stat-total").textContent = totalUnits();
  $("#bb-stat-critical").textContent = criticalGroupCount();
  $("#bb-stat-donors").textContent = donors.filter((d) => d.status === "eligible").length;

  const incoming = [];
  if (state.currentRequest && !state.currentRequest.resolved && state.currentRequest.stage >= 3) {
    incoming.push(state.currentRequest);
  }
  $("#bb-stat-requests").textContent = incoming.length;

  $("#bb-incoming-requests").innerHTML =
    incoming.length === 0
      ? `<p class="empty-state">No incoming coordination requests right now.</p>`
      : incoming
          .map(
            (r) => `
      <div class="request-row">
        <div class="request-row-main">
          <strong>${r.id} · ${r.bloodGroup} · ${r.units} units</strong>
          <span>${r.location} · Priority: ${r.priority}</span>
        </div>
        <span class="pill pill-critical">Awaiting confirmation</span>
      </div>`
          )
          .join("");

  renderInventoryGrid("#inventory-grid-bb");
}

function renderDonorDashboard() {
  const group = "O+";
  $("#donor-profile-group").textContent = group;
  const cooldownBadge = $("#donor-cooldown-badge");
  cooldownBadge.textContent = "Eligible Now";
  cooldownBadge.className = "badge badge-available";

  const nearby = donors.filter((d) => d.group === group).slice(0, 3);
  $("#donor-nearby-requests").innerHTML = nearby.length
    ? `
      <div class="request-row">
        <div class="request-row-main">
          <strong>${group} needed · Critical priority</strong>
          <span>St. Xavier General Hospital · 2.4 km away</span>
        </div>
        <span class="pill pill-critical">New</span>
      </div>`
    : `<p class="empty-state">No nearby requests right now.</p>`;
}

function renderAdminDashboard() {
  const critical = criticalGroupCount();
  const active = 3 + (state.currentRequest && !state.currentRequest.resolved ? 1 : 0);
  const resolved = 128 + state.requestHistory.length;

  $("#admin-stat-units").textContent = totalUnits() * 42; // simulated network-wide scaling
  $("#admin-stat-critical").textContent = critical;
  $("#admin-stat-active").textContent = active;
  $("#admin-stat-donors").textContent = 340;

  // Inventory bars
  $("#admin-inventory-bars").innerHTML = BLOOD_GROUPS.map((g) => {
    const data = bloodInventory[g];
    const status = statusForUnits(data.units);
    const pct = Math.min(100, Math.round((data.units / 24) * 100));
    return `
      <div class="bar-stat-row">
        <span class="bar-label">${g}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:${statusColorVar(status)}"></div></div>
        <span class="bar-value">${data.units}</span>
      </div>`;
  }).join("");

  // Request rings
  const total = active + resolved;
  const activePct = Math.round((active / total) * 100);
  const resolvedPct = 100 - activePct;
  $("#admin-request-rings").innerHTML = `
    <div class="ring" style="background:conic-gradient(var(--red) 0% ${activePct}%, var(--bg-panel-2) ${activePct}% 100%)">
      <div class="ring-inner"><strong>${active}</strong><span>Active</span></div>
    </div>
    <div class="ring" style="background:conic-gradient(var(--green) 0% ${resolvedPct}%, var(--bg-panel-2) ${resolvedPct}% 100%)">
      <div class="ring-inner"><strong>${resolved}</strong><span>Resolved</span></div>
    </div>`;

  // Network stats
  $("#admin-network-stats").innerHTML = `
    <div class="network-stat-row"><span>Partner Blood Banks</span><strong>18</strong></div>
    <div class="network-stat-row"><span>Verified Donors</span><strong>340</strong></div>
    <div class="network-stat-row"><span>Partner Hospitals</span><strong>24</strong></div>`;
}

/* ---------------------------------------------------------------
   9. DONORS PAGE
---------------------------------------------------------------- */
function renderDonorsPage() {
  $("#donors-grid").innerHTML = donors
    .map((d) => {
      const badge =
        d.status === "eligible"
          ? `<span class="badge badge-available">Eligible</span>`
          : `<span class="badge badge-cooldown">Cooldown</span>`;
      return `
      <div class="donor-card">
        <div class="donor-card-top">
          <div class="donor-avatar-sm">${d.name.charAt(0)}</div>
          <div>
            <div class="donor-name">${d.name}</div>
            <div class="donor-group">${d.group}</div>
          </div>
        </div>
        <div class="badge-row">
          <span class="badge badge-verified">Verified</span>
          ${badge}
        </div>
        <div class="donor-meta">
          <span>${d.distance} km away</span>
          <span>Demo verification</span>
        </div>
      </div>`;
    })
    .join("");
}

/* ---------------------------------------------------------------
   10. NOTIFICATIONS PAGE
---------------------------------------------------------------- */
function renderNotificationsPage() {
  $("#notifications-list").innerHTML = notifications
    .map(
      (n) => `
      <div class="notif-row">
        <span class="notif-icon">${n.icon}</span>
        <div class="notif-body">
          <strong>${n.title}</strong>
          <span>${n.time}</span>
        </div>
      </div>`
    )
    .join("");
}

/* ---------------------------------------------------------------
   11. HISTORY PAGE
---------------------------------------------------------------- */
function renderHistoryPage() {
  const el = $("#history-list");
  if (state.requestHistory.length === 0) {
    el.innerHTML = `<p class="empty-state">No requests yet. Create an Emergency Blood Request to see it appear here once resolved.</p>`;
    return;
  }
  el.innerHTML = state.requestHistory
    .slice()
    .reverse()
    .map(
      (r) => `
      <div class="history-row">
        <div class="history-row-main">
          <strong>${r.id} · ${r.bloodGroup} · ${r.units} units</strong>
          <span>${r.location} · Resolved via ${r.matchedResource}</span>
        </div>
        <span class="pill pill-success">Resolved</span>
      </div>`
    )
    .join("");
}

/* ---------------------------------------------------------------
   12. EMERGENCY REQUEST FORM
---------------------------------------------------------------- */
function initEmergencyForm() {
  $("#btn-emergency-cta").addEventListener("click", () => navigateTo("emergency"));

  $all(".priority-opt").forEach((btn) => {
    btn.addEventListener("click", () => {
      $all(".priority-opt").forEach((b) => b.classList.remove("selected"));
      btn.classList.add("selected");
    });
  });

  $("#emergency-form").addEventListener("submit", (e) => {
    e.preventDefault();

    const bloodGroup = $("#er-blood-group").value;
    const units = parseInt($("#er-units").value, 10);
    const location = $("#er-location").value.trim();
    const notes = $("#er-notes").value.trim();
    const priorityBtn = $(".priority-opt.selected");

    if (!bloodGroup || !location || !units || units < 1) {
      showToast("Please fill in all required fields.", "warning");
      return;
    }

    state.requestCounter += 1;
    const request = {
      id: "#BL-" + state.requestCounter,
      bloodGroup,
      units,
      priority: priorityBtn ? priorityBtn.dataset.value : "Normal",
      location,
      notes,
      stage: 0, // see NOTIFY_STEPS / RESOLVE_STEPS thresholds
      matches: [],
      selectedMatchIndex: 0,
      matchedResource: null,
      resolved: false,
    };
    state.currentRequest = request;

    pushNotification("🚨", `New ${request.priority.toLowerCase()} request created: ${request.id} for ${bloodGroup}`);
    showToast(`Emergency request ${request.id} created. Searching for matches…`, "success");
    renderAll();

    navigateTo("matching");
    runSmartMatching();
  });
}

/* ---------------------------------------------------------------
   13. SMART MATCHING
---------------------------------------------------------------- */
function generateMatches(request) {
  const group = request.bloodGroup;

  const bankMatches = bloodBankPool.slice(0, 2).map((bank) => ({
    type: "bloodbank",
    name: bank.name,
    bloodGroup: group,
    units: bank.baseUnits,
    distance: bank.baseDistance,
    score: bank.baseScore,
  }));

  const donorMatch = donors.find((d) => d.group === group && d.status === "eligible") || donors[0];

  const donorEntry = {
    type: "donor",
    name: "Verified Donor",
    displayName: donorMatch.name,
    bloodGroup: group,
    units: null,
    distance: donorMatch.distance,
    score: 82,
  };

  return [...bankMatches, donorEntry];
}

function matchCardHTML(match, index, isSelected) {
  const rank = index + 1;
  const subtitle = match.type === "bloodbank" ? match.name : `${match.name} (${match.displayName})`;
  const unitsRow = match.type === "bloodbank" ? `<span>Available Units: <b>${match.units}</b></span>` : "";
  return `
    <div class="match-card ${isSelected ? "selected" : ""}" data-index="${index}">
      <div class="match-rank">#${rank}</div>
      <div class="match-info">
        <div class="match-info-top">
          <strong>${subtitle}</strong>
          <span class="pill pill-neutral">${match.bloodGroup}</span>
        </div>
        <div class="match-meta">
          ${unitsRow}
          <span>Distance: <b>${match.distance} km</b></span>
          <span>Verification: <b>Verified</b></span>
          <span>Availability: <b>Available</b></span>
        </div>
      </div>
      <div class="match-score">
        <div class="match-score-value">${match.score}%</div>
        <div class="match-score-label">Match Score</div>
      </div>
    </div>`;
}

function renderMatches(request) {
  $("#match-list").innerHTML = request.matches
    .map((m, i) => matchCardHTML(m, i, i === request.selectedMatchIndex))
    .join("");

  $all(".match-card").forEach((card) => {
    card.addEventListener("click", () => {
      request.selectedMatchIndex = parseInt(card.dataset.index, 10);
      renderMatches(request);
      $("#btn-select-match").disabled = false;
    });
  });
}

function runSmartMatching() {
  const request = state.currentRequest;
  $("#matching-loading").classList.remove("hidden");
  $("#matching-results").classList.add("hidden");
  $("#matching-subtitle").textContent = "Finding the most suitable verified resources...";

  setTimeout(() => {
    request.matches = generateMatches(request);
    request.stage = 1; // matching completed
    renderMatches(request);

    $("#matching-loading").classList.add("hidden");
    $("#matching-results").classList.remove("hidden");
    $("#matching-subtitle").textContent = `${request.matches.length} verified resources found for ${request.bloodGroup}.`;
    $("#btn-select-match").disabled = false;
  }, 1500);
}

function initMatching() {
  $("#btn-select-match").addEventListener("click", () => {
    const request = state.currentRequest;
    const match = request.matches[request.selectedMatchIndex];
    request.matchedResource = match.type === "bloodbank" ? match.name : `${match.displayName} (Verified Donor)`;
    request.stage = 3; // resource found + notification in progress
    renderAll();

    showToast(`${request.matchedResource} selected as best match.`, "success");
    pushNotification("🔎", `Smart matching completed for ${request.id}`);

    navigateTo("notify");
    renderNotifyPage();
  });
}

/* ---------------------------------------------------------------
   14. NOTIFY & COORDINATE
---------------------------------------------------------------- */
function renderTimeline(ulId, steps, stageIndex) {
  const ul = $(ulId);
  ul.innerHTML = steps
    .map((step) => {
      let cls = "";
      let symbol = "○";
      if (stageIndex > step.threshold) {
        cls = "done";
        symbol = "✓";
      } else if (stageIndex === step.threshold) {
        cls = "current";
        symbol = "●";
      }
      return `<li class="${cls}">${symbol} ${step.label}</li>`;
    })
    .join("");
}

function renderNotifyPage() {
  const r = state.currentRequest;
  $("#notify-request-id").textContent = r.id;
  $("#notify-priority-pill").textContent = r.priority;
  $("#notify-priority-pill").className =
    "pill " + (r.priority === "Critical" ? "pill-critical" : r.priority === "Urgent" ? "pill-warning" : "pill-success");
  $("#notify-blood-group").textContent = r.bloodGroup;
  $("#notify-units").textContent = r.units;
  $("#notify-resource").textContent = r.matchedResource;

  renderTimeline("#notify-timeline", NOTIFY_STEPS, r.stage);

  $("#notify-feed").innerHTML = `<div class="feed-item">📨 <strong>${r.matchedResource}</strong> has been notified about ${r.bloodGroup} request ${r.id}.</div>`;
  $("#btn-simulate-confirmation").classList.remove("hidden");
  $("#btn-proceed-collection").classList.add("hidden");
}

function initNotifyPage() {
  $("#btn-simulate-confirmation").addEventListener("click", () => {
    const r = state.currentRequest;
    r.stage = 5; // notification sent -> done, blood collection -> current
    renderTimeline("#notify-timeline", NOTIFY_STEPS, r.stage);

    const feed = $("#notify-feed");
    const item = document.createElement("div");
    item.className = "feed-item feed-success";
    item.innerHTML = `✅ <strong>${r.matchedResource}</strong> confirmed availability and is preparing the units for dispatch.`;
    feed.appendChild(item);

    showToast(`${r.matchedResource} confirmed the request.`, "success");
    pushNotification("✅", `${r.matchedResource} confirmed request ${r.id}`);

    $("#btn-simulate-confirmation").classList.add("hidden");
    $("#btn-proceed-collection").classList.remove("hidden");
  });

  $("#btn-proceed-collection").addEventListener("click", () => {
    navigateTo("resolve");
    renderResolvePage();
  });
}

/* ---------------------------------------------------------------
   15. RECEIVE & RESOLVE
---------------------------------------------------------------- */
function renderResolvePage() {
  const r = state.currentRequest;
  $("#resolve-request-id").textContent = r.id;
  $("#resolve-blood-group").textContent = r.bloodGroup;
  $("#resolve-units").textContent = r.units;
  $("#resolve-hospital").textContent = r.location;
  $("#resolve-resource").textContent = r.matchedResource;
  $("#resolve-status-pill").textContent = "In Progress";
  $("#resolve-status-pill").className = "pill pill-warning";

  renderTimeline("#resolve-timeline", RESOLVE_STEPS, r.stage);

  $("#resolve-success").classList.add("hidden");
  $("#btn-confirm-received").classList.remove("hidden");
}

function initResolvePage() {
  $("#btn-confirm-received").addEventListener("click", () => {
    const r = state.currentRequest;
    r.stage = 7; // beyond final threshold -> everything shows as done
    r.resolved = true;

    renderTimeline("#resolve-timeline", RESOLVE_STEPS, r.stage);
    $("#resolve-status-pill").textContent = "Resolved";
    $("#resolve-status-pill").className = "pill pill-success";

    // Deduct units from inventory if matched with a blood bank (simulated fulfillment)
    if (bloodInventory[r.bloodGroup]) {
      bloodInventory[r.bloodGroup].units = Math.max(0, bloodInventory[r.bloodGroup].units - r.units);
    }

    state.requestHistory.push(r);
    pushNotification("🎉", `Request ${r.id} successfully resolved`);
    showToast("Emergency request successfully resolved.", "success");

    $("#resolve-success-id").textContent = r.id;
    $("#resolve-success").classList.remove("hidden");
    $("#btn-confirm-received").classList.add("hidden");

    renderAll();
  });
}

/* ---------------------------------------------------------------
   16. INIT
---------------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  initLanding();
  initLogout();
  initNav();
  initEmergencyForm();
  initMatching();
  initNotifyPage();
  initResolvePage();
});
